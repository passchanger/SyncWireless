<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2024-04-16 01:51:30 --> UTF-8 Support Enabled
DEBUG - 2024-04-16 01:51:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-16 01:51:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-16 01:51:30 --> Total execution time: 0.0411
DEBUG - 2024-04-16 01:51:31 --> UTF-8 Support Enabled
DEBUG - 2024-04-16 01:51:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-16 01:51:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-16 01:51:31 --> Total execution time: 0.0519
DEBUG - 2024-04-16 01:51:31 --> UTF-8 Support Enabled
DEBUG - 2024-04-16 01:51:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-04-16 01:51:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2024-04-16 01:51:31 --> Total execution time: 0.0405
