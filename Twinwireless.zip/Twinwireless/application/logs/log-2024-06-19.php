<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-06-19 08:37:03 --> Config Class Initialized
INFO - 2024-06-19 08:37:03 --> Hooks Class Initialized
DEBUG - 2024-06-19 08:37:03 --> UTF-8 Support Enabled
INFO - 2024-06-19 08:37:03 --> Utf8 Class Initialized
INFO - 2024-06-19 08:37:03 --> URI Class Initialized
INFO - 2024-06-19 08:37:03 --> Router Class Initialized
INFO - 2024-06-19 08:37:03 --> Output Class Initialized
INFO - 2024-06-19 08:37:03 --> Security Class Initialized
DEBUG - 2024-06-19 08:37:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-19 08:37:03 --> Input Class Initialized
INFO - 2024-06-19 08:37:03 --> Language Class Initialized
INFO - 2024-06-19 08:37:03 --> Loader Class Initialized
INFO - 2024-06-19 08:37:03 --> Helper loaded: url_helper
INFO - 2024-06-19 08:37:03 --> Database Driver Class Initialized
INFO - 2024-06-19 08:37:03 --> Helper loaded: form_helper
INFO - 2024-06-19 08:37:03 --> Form Validation Class Initialized
DEBUG - 2024-06-19 08:37:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-19 08:37:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-19 08:37:03 --> Controller Class Initialized
INFO - 2024-06-19 08:37:03 --> Model "Campaign_model" initialized
INFO - 2024-06-19 08:37:03 --> File loaded: C:\xampp2\htdocs\codeig\application\views\campaign.php
DEBUG - 2024-06-19 08:37:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-06-19 08:37:03 --> Final output sent to browser
DEBUG - 2024-06-19 08:37:03 --> Total execution time: 0.0753
INFO - 2024-06-19 08:37:06 --> Config Class Initialized
INFO - 2024-06-19 08:37:06 --> Hooks Class Initialized
DEBUG - 2024-06-19 08:37:06 --> UTF-8 Support Enabled
INFO - 2024-06-19 08:37:06 --> Utf8 Class Initialized
INFO - 2024-06-19 08:37:06 --> URI Class Initialized
INFO - 2024-06-19 08:37:06 --> Router Class Initialized
INFO - 2024-06-19 08:37:06 --> Output Class Initialized
INFO - 2024-06-19 08:37:06 --> Security Class Initialized
DEBUG - 2024-06-19 08:37:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-19 08:37:06 --> Input Class Initialized
INFO - 2024-06-19 08:37:06 --> Language Class Initialized
INFO - 2024-06-19 08:37:06 --> Loader Class Initialized
INFO - 2024-06-19 08:37:06 --> Helper loaded: url_helper
INFO - 2024-06-19 08:37:06 --> Database Driver Class Initialized
INFO - 2024-06-19 08:37:06 --> Helper loaded: form_helper
INFO - 2024-06-19 08:37:06 --> Form Validation Class Initialized
DEBUG - 2024-06-19 08:37:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-19 08:37:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-19 08:37:06 --> Controller Class Initialized
INFO - 2024-06-19 08:37:06 --> Model "Campaign_model" initialized
INFO - 2024-06-19 08:37:06 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2024-06-19 08:37:06 --> Updating campaign with ID: 8
INFO - 2024-06-19 08:37:06 --> Config Class Initialized
INFO - 2024-06-19 08:37:06 --> Hooks Class Initialized
DEBUG - 2024-06-19 08:37:06 --> UTF-8 Support Enabled
INFO - 2024-06-19 08:37:06 --> Utf8 Class Initialized
INFO - 2024-06-19 08:37:06 --> URI Class Initialized
INFO - 2024-06-19 08:37:06 --> Router Class Initialized
INFO - 2024-06-19 08:37:06 --> Output Class Initialized
INFO - 2024-06-19 08:37:06 --> Security Class Initialized
DEBUG - 2024-06-19 08:37:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-19 08:37:06 --> Input Class Initialized
INFO - 2024-06-19 08:37:06 --> Language Class Initialized
INFO - 2024-06-19 08:37:06 --> Loader Class Initialized
INFO - 2024-06-19 08:37:06 --> Helper loaded: url_helper
INFO - 2024-06-19 08:37:06 --> Database Driver Class Initialized
INFO - 2024-06-19 08:37:06 --> Helper loaded: form_helper
INFO - 2024-06-19 08:37:06 --> Form Validation Class Initialized
DEBUG - 2024-06-19 08:37:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-06-19 08:37:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-19 08:37:06 --> Controller Class Initialized
INFO - 2024-06-19 08:37:06 --> Model "Campaign_model" initialized
INFO - 2024-06-19 08:37:06 --> File loaded: C:\xampp2\htdocs\codeig\application\views\campaign.php
DEBUG - 2024-06-19 08:37:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2024-06-19 08:37:06 --> Final output sent to browser
DEBUG - 2024-06-19 08:37:06 --> Total execution time: 0.0710
