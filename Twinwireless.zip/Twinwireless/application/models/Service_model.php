<?php
class Service_model extends CI_Model
{
    public function getALLService()
    {
        $query = $this->db->get('service_centres');
        if ($query) {
            return $query->result();
        }
    }
    public function insert_Service($data)
    {
        $query = $this->db->insert('service_centres', $data);
        if ($query) {
            return true;
        } else {
            return false;
        }
    }
    public function getSingleService($id)
    {
        $this->db->where('id', $id);
        $query = $this->db->get('service_centres');
        if ($query) {
            return $query->row();
        }
    }
    public function update_Service($data, $id)
    {
        var_dump($id);
        exit;
        $this->db->where('id', $id);
        $query = $this->db->update('service_centres', $data);
        if ($query) {
            return true;
        } else {
            return false;
        }
    }
    public function deleteitems($id)
    {
        $this->db->where('id', $id);
        $query = $this->db->delete('service_centres');
        if ($query) {
            return true;
        } else {
            return false;
        }
    }
}
